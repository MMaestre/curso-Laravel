<?php
/**
 * @author MMaestre
 * @version 1.0.3
 * @internal
 */
namespace Usuario;
    class Persona {
        private $nombre;
        private $apellido;

        /**
         * @return mixed
         */
        public function getNombre():string
        {
            return $this->nombre;
        }

        /**
         * @param mixed $nombre
         */
        public function setNombre(string $nombre)
        {
            $this->nombre = $nombre;
        }

        /**
         * @return mixed
         */
        public function getApellido():string
        {
            return $this->apellido;
        }

        /**
         * @param mixed $apellido
         */
        public function setApellido(string $apellido)
        {
            $this->apellido = $apellido;
        }


    }